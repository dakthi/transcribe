import os
import whisper
import torch
import pandas as pd
import logging
import time
import subprocess
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    filename="transcription.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="w",  # Overwrites the log file on each run
)

# Define paths
MASTER_FOLDER = os.path.expanduser("~/Downloads/Organized/Folders/Folders/python-transcribe")
CSV_FILE = os.path.join(MASTER_FOLDER, "transcription.csv")
SEGMENTS_FOLDER = os.path.join(MASTER_FOLDER, "segments")  # New folder to store segments

# Ensure segments folder exists
os.makedirs(SEGMENTS_FOLDER, exist_ok=True)

# Load Whisper model with FP32 enforcement
MODEL_NAME = "turbo"  # Choose "tiny", "base", "small", "medium", "large", "turbo"
model = whisper.load_model(MODEL_NAME).to(torch.float32)  # 🔥 Force FP32

def ensure_csv_exists():
    """Create CSV file with headers if it doesn't exist."""
    if not os.path.exists(CSV_FILE):
        logging.info("CSV file not found. Creating a new one.")
        df = pd.DataFrame(columns=["Filename", "Transcription"])
        df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

def load_existing_transcriptions():
    """Load existing transcriptions from CSV to avoid re-processing files."""
    if os.path.exists(CSV_FILE):
        df = pd.read_csv(CSV_FILE)
        if "Filename" in df:
            return set(df["Filename"].apply(os.path.basename).astype(str))
    return set()

def update_csv(filename, transcription):
    """Update CSV file with the transcription in real-time."""
    base_filename = os.path.basename(filename)
    try:
        df = pd.read_csv(CSV_FILE)
    except Exception as e:
        logging.error(f"[ERROR] Reading CSV: {e}")
        df = pd.DataFrame(columns=["Filename", "Transcription"])

    if base_filename in df["Filename"].apply(os.path.basename).values:
        df.loc[df["Filename"].apply(os.path.basename) == base_filename, "Transcription"] = transcription
    else:
        new_row = pd.DataFrame([{"Filename": base_filename, "Transcription": transcription}])
        df = pd.concat([df, new_row], ignore_index=True)

    df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

def transcribe_audio_local(file_path):
    """
    Transcribe audio by first splitting it into 30-second segments using ffmpeg,
    then processing each segment with the local Whisper model.
    Uses tqdm for progress display and updates CSV in real-time.
    """
    base_filename = os.path.basename(file_path)
    logging.info(f"[START] Transcribing: {base_filename}")
    transcription = ""

    try:
        # Create a persistent directory for the segments of this file.
        file_segments_dir = os.path.join(SEGMENTS_FOLDER, os.path.splitext(base_filename)[0])
        os.makedirs(file_segments_dir, exist_ok=True)
        
        # Build output pattern for the segments.
        output_pattern = os.path.join(file_segments_dir, f"{base_filename}_%03d.wav")
        
        # Run ffmpeg to split the audio file into 30-second segments.
        cmd = [
            "ffmpeg",
            "-i", file_path,
            "-f", "segment",
            "-segment_time", "30",
            "-c:a", "pcm_s16le",  # re-encode audio to PCM 16-bit little-endian
            "-ar", "16000",       # set sample rate to 16kHz
            "-ac", "1",           # set to mono audio
            output_pattern
        ]
        subprocess.run(cmd, check=True)
        
        # List and sort segment files.
        segment_files = sorted(
            [os.path.join(file_segments_dir, f) for f in os.listdir(file_segments_dir) if f.endswith(".wav")]
        )
        total_segments = len(segment_files)
        if total_segments == 0:
            logging.error(f"[ERROR] No segments created for {base_filename}.")
            return None

        # Detect language using the first segment.
        lang_result = model.transcribe(segment_files[0], fp16=False)
        detected_lang = lang_result["language"]
        logging.info(f"[INFO] Detected Language: {detected_lang}")

        # Process each segment.
        with tqdm(total=total_segments, desc=f"Processing {base_filename}", unit="segment") as pbar:
            for seg in segment_files:
                result = model.transcribe(seg, fp16=False)
                transcription += " " + result["text"]
                update_csv(base_filename, transcription.strip())  # Update CSV in real-time
                pbar.update(1)
                time.sleep(0.1)  # Small delay for better log visibility

        logging.info(f"[COMPLETED] {base_filename} - Transcription saved.")
        return transcription

    except Exception as e:
        logging.error(f"[ERROR] Transcribing {base_filename}: {e}")
        return None

def main():
    """Process and transcribe new audio files in the folder."""
    if not os.path.exists(MASTER_FOLDER):
        logging.error(f"[ERROR] Folder '{MASTER_FOLDER}' does not exist.")
        return

    ensure_csv_exists()
    existing_files = load_existing_transcriptions()

    for file in os.listdir(MASTER_FOLDER):
        if file.endswith((".mp3", ".wav", ".m4a", ".WAV", ".MP3")):
            if file in existing_files:
                logging.info(f"[SKIP] Already processed: {file}")
                continue

            file_path = os.path.join(MASTER_FOLDER, file)
            logging.info(f"[PROCESSING] {file}")

            transcript = transcribe_audio_local(file_path)

            if transcript:
                logging.info(f"[DONE] {file} - Transcription saved.")

if __name__ == "__main__":
    main()
